# TALAN: Technical Alogorithmic Analytics

## TALAN is a python package that provides a list of functions for technical analysis
### To install
`pip install git+https://github.com/beyondbond/talan --upgrade --user`
### or
`git clone https://github.com/beyondbond/talan`
`cd talan`
`pip install --upgrade --user .`
